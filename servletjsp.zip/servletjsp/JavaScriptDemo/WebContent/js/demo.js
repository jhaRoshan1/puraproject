function sayHello(){
	document.write("Hello world on web browser")
	console.log("hello world on console")
}