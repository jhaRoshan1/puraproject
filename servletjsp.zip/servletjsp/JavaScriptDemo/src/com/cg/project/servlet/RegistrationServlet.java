package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String pancard=request.getParameter("pancard");
		String yearlyInvestmentUnder80C=request.getParameter("yearlyInvestmentUnder80C");
		String bankName=request.getParameter("bankName");
		String accountNo=request.getParameter("accountNo");
		String ifscCode=request.getParameter("ifscCode");
		
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<div>");
		if(firstName.isEmpty()||lastName.isEmpty()||emailId.isEmpty()||department.isEmpty()||designation.isEmpty()||pancard.isEmpty()||yearlyInvestmentUnder80C.isEmpty()||
				bankName.isEmpty()||accountNo.isEmpty()||ifscCode.isEmpty())
			out.println("<font color='green' size='10'>please provide required field</font>");
		else
			out.println("<font color='red' size='10'>user registered</font>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
