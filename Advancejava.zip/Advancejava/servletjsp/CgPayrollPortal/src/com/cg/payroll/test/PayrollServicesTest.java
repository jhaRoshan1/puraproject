package com.cg.payroll.test;

public class PayrollServicesTest {

	/*private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new PayrollServicesImpl();
	}
@Before
public void setUpTestData() {
	Associate associate=new Associate(101, 88000, "Roshan", "Jha", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
	Associate associate2=new Associate(102, 88000, "Harsh", "Priya", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
	PayRollDBUtil.associates.put(associate.getAssociatedId(),associate);
	PayRollDBUtil.associates.put(associate2.getAssociatedId(),associate2);

	PayRollDBUtil.ASSOCIATE_ID_COUNTER=102;
}
@Test(expected=AssociateDetailsNotFoundException.class)
public void testGetAssociateDetailsForInvalidAssociateId()throws AssociateDetailsNotFoundException{
	services.getAssociateDetails(12345);
}
@Test
public void testGetAssociateDetailsForValidAssociateId()throws AssociateDetailsNotFoundException{
	Associate expectedAssociate=new Associate(101, 88000, "Roshan", "Jha", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
	Associate actualAssociate=services.getAssociateDetails(101);
	Assert.assertEquals(expectedAssociate, actualAssociate);
}
@Test
public void testAcceptAssociateDetailsForValidData() {
	int expectedId=103;
	int actualId=services.acceptAssociateDetails("saiyam", "lunia", "staff", "Manager", "irctfff", "lunjahsagxjhg@capgemini.com", 800000, 12345, "citi", "45hg", 20000	, 1000	, 1000);
	Assert.assertEquals(expectedId, actualId);	
}
@Test(expected=AssociateDetailsNotFoundException.class)
public void testCalculateNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
	services.getAssociateDetails(12345);
}
@Test
public void testCalculateNetSalaryForValidAssociateId()throws AssociateDetailsNotFoundException{
	int expectedNetSalary=0;
	double actualNetSalary=services.calculateNetSalary(102);
	Assert.assertEquals(expectedNetSalary, actualNetSalary);
}
@Test
public void testGetAllAssociatesDetails() {
	Associate associate1=new Associate(101, 88000, "Roshan", "Jha", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
	Associate associate2=new Associate(102, 88000, "Harsh", "Priya", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
	ArrayList<Associate>expectedAssociatesList=new ArrayList<>();
	expectedAssociatesList.add(associate1);
	expectedAssociatesList.add(associate2);
	ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)services.getAllAssociateDetails();
	Assert.assertEquals(expectedAssociatesList,actualAssociateList);
}
@After
public void tearDownTestData() {
	PayRollDBUtil.associates.clear();
	PayRollDBUtil.ASSOCIATE_ID_COUNTER=100;
	
}
@AfterClass
public static void tearDownTestEnv() {
	services=null;
}*/
	
}



