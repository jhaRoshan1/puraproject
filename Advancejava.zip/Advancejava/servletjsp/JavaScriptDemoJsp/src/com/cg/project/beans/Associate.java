package com.cg.project.beans;

public class Associate {
	private int associateId;
	private String Password,firstName,lastName,department,designation,pancard,bankName,ifscCode,yearlyInvestmentUnder80C,accountNo;
	public Associate() {
		super();
	}



	public Associate(int associateId, String firstName, String lastName, String department, String designation,
			String pancard, String bankName, String ifscCode, String yearlyInvestmentUnder80C, String accountNo) {
		super();
		this.associateId = associateId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.bankName = bankName;
		this.ifscCode = ifscCode;
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
		this.accountNo = accountNo;
	}

	public int getAssociateId() {
		return associateId;
	}

	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getDepartment() {
		return department;
	}



	public void setDepartment(String department) {
		this.department = department;
	}



	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public String getPancard() {
		return pancard;
	}



	public void setPancard(String pancard) {
		this.pancard = pancard;
	}



	public String getBankName() {
		return bankName;
	}



	public void setBankName(String bankName) {
		this.bankName = bankName;
	}



	public String getIfscCode() {
		return ifscCode;
	}



	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}



	public String getYearlyInvestmentUnder80C() {
		return yearlyInvestmentUnder80C;
	}



	public void setYearlyInvestmentUnder80C(String yearlyInvestmentUnder80C) {
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
	}



	public String getAccountNo() {
		return accountNo;
	}



	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}



	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", yearlyInvestmentUnder80C=" + yearlyInvestmentUnder80C
				+ ", accountNo=" + accountNo + ", firstName=" + firstName + ", lastName=" + lastName + ", department="
				+ department + ", designation=" + designation + ", pancard=" + pancard + ", bankName=" + bankName
				+ ", ifscCode=" + ifscCode + "]";
	}



	public Associate(int associateId, String password) {
		super();
		this.associateId = associateId;
		Password = password;
	}

}
