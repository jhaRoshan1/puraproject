package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDao);

	}
	@Before
	public void setUpTestMockData() {
		Associate associate1=new Associate(101, 88000, "Roshan", "Jha", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
		Associate associate2=new Associate(102, 88000, "Harsh", "Priya", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
		Associate associate3=new Associate(103, 88000, "swastik", "Bhattacharya", "Staff", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));

		ArrayList<Associate>associatesList=new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);

		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associatesList);
		EasyMock.replay(mockAssociateDao);

	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	@Test
	public void testGetAssociateDetailsForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(101, 88000, "Roshan", "Jha", "Trainee", "software engineer", "hwd1545", "jharoshan890@gmail.com", new Salary(38000, 2000, 2000), new BankDetails(924578, "ICICI", "idwm1254"));
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		assertEquals(expectedAssociate, actualAssociate);
		EasyMock.verify(mockAssociateDao.findOne(101));
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDao);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}
}